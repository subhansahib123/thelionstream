@include('Frontend.includes.head')

@include('Frontend.includes.header')

@yield('content')

@include('Frontend.includes.footer')

@include('Frontend.includes.foot')
