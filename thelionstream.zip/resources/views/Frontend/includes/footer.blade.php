<footer>
        {{-- <div class="row mx-2">
            <div class="col-md-6 col-lg-5 ">
                <h4>about</h4>
                <p>Lions Streams is your one-stop shop. For all business needs.Development, Design &Business cards.
                    Also,
                    We provide you with your own Wholesale/Retail Site,</p>
                <div style="margin-top: 35px;margin-bottom: 40px;">
                    <a href="" class="social-btn"><i class="fa-brands fa-square-facebook" style="margin-right: 7px;font-size: 23px;"></i>LIKE US ON FACEBOOK</a>
                </div>
            </div>
            <div class="col-md-6 col-lg-4 ">
                <h4>helpful links</h4>
                <div class="row">
                    <ul class="footer-links">
                        <li><a href="">About Us</a></li>
                        <li><a href="">Services</a></li>
                    </ul>
                    <ul class="footer-links">
                        <li><a href="">Contact</a></li>
                        <li><a href="">Testimonials</a></li>
                    </ul>
                </div>
            </div>
            <div class="col-md-12 col-lg-3 ">
                <h4>contact us</h4>
                <div class="text-widget">
                    <span>City Mall Plaza Chen One Raod,</span>
                    <br>
                    Phone: <span>0000-0000000</span>
                    <br>
                    Email: <span>sample123@gmial.com</span>
                </div>
            </div>
        </div> --}}
        <div class="container">
            <div class="row ending">
                <div class="col-md-12">
                    <p>© Copyright 2021 by <a href="">Lion Streams</a>. All Rights Reserved. <a href="">Terms &
                            Condition</a></p>
                </div>
            </div>
        </div>
    </footer>
